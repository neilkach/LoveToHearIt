package com.example.lovetohearit;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class PlayingActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_playing);
    }
}
