package com.example.lovetohearit;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.text.Layout;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;


import com.amazonaws.auth.CognitoCachingCredentialsProvider;
import com.amazonaws.mobile.client.AWSMobileClient;
import com.amazonaws.mobileconnectors.cognitoidentityprovider.CognitoDevice;
import com.amazonaws.mobileconnectors.cognitoidentityprovider.CognitoUser;
import com.amazonaws.mobileconnectors.cognitoidentityprovider.CognitoUserSession;
import com.amazonaws.mobileconnectors.cognitoidentityprovider.continuations.AuthenticationContinuation;
import com.amazonaws.mobileconnectors.cognitoidentityprovider.continuations.ChallengeContinuation;
import com.amazonaws.mobileconnectors.cognitoidentityprovider.continuations.MultiFactorAuthenticationContinuation;
import com.amazonaws.mobileconnectors.cognitoidentityprovider.handlers.AuthenticationHandler;
import com.amazonaws.mobileconnectors.s3.transferutility.TransferListener;
import com.amazonaws.mobileconnectors.s3.transferutility.TransferObserver;
import com.amazonaws.mobileconnectors.s3.transferutility.TransferState;
import com.amazonaws.mobileconnectors.s3.transferutility.TransferUtility;
import com.amazonaws.services.s3.AmazonS3Client;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class RecordingActivity extends AppCompatActivity {

    private static final String LOG_TAG = "AudioRecord";
    private static final int REQUEST_RECORD_AUDIO_PERMISSION = 200;
    private static String fileName = null;

    private boolean startRecording = true;
    private MediaRecorder recorder = null;

    private boolean startPlaying = true;
    private MediaPlayer player = null;

    // Requesting permission to RECORD_AUDIO
    private boolean permissionToRecordAccepted = false;
    private String [] permissions = {Manifest.permission.RECORD_AUDIO};

    private CognitoCachingCredentialsProvider credentialsProvider;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recording);

        AWSMobileClient.getInstance().initialize(this).execute();

        // Record to the external cache directory for visibility
        fileName = getExternalCacheDir().getAbsolutePath();
        fileName += "/audiorecording.3gp";

        ActivityCompat.requestPermissions(this, permissions, REQUEST_RECORD_AUDIO_PERMISSION);

        TextView tv = findViewById(R.id.test);

        tv.setText(fileName);
    }

    //helper class that refreshes authentification credentials
    private class RefreshAsyncTask extends AsyncTask<Integer, Void, Integer> {
        @Override
        protected Integer doInBackground(Integer... integers) {
            credentialsProvider.refresh();
            return integers[0];
        }

        @Override
        protected void onPostExecute(Integer action) {
            choose(action);
        }
    }

    //authentication proceedings, checks whether user is logged in
    private void act(final int action) {
        final CognitoSettings cognitoSettings = new CognitoSettings(this);

        //identity pool credentials provider
        credentialsProvider = cognitoSettings.getCredentialsProvider();

        //get user - User Pool
        CognitoUser currentUser = cognitoSettings.getUserPool().getCurrentUser();

        //get token for logged in user - user pool
        currentUser.getSessionInBackground(new AuthenticationHandler() {
            @Override
            public void onSuccess(CognitoUserSession userSession, CognitoDevice newDevice) {
                //if user is authenticated
                if (userSession.isValid()) {
                    //get id token from cognito user session
                    String idToken = userSession.getIdToken().getJWTToken();

                    if (idToken.length() > 0) {
                        //set up as a credentials provider
                        Map<String, String> logins = new HashMap<>();
                        logins.put("cognito-idp.us-east-1.amazonaws.com/us-east-1_28LCEkvlZ", idToken);
                        credentialsProvider.setLogins(logins);

                        //refresh provider off main thread
                        new RefreshAsyncTask().execute(action);
                    }

                    choose(action);
                }
            }

            @Override
            public void getAuthenticationDetails(AuthenticationContinuation authenticationContinuation, String userId) {
                choose(action);
            }

            @Override
            public void getMFACode(MultiFactorAuthenticationContinuation continuation) {

            }

            @Override
            public void authenticationChallenge(ChallengeContinuation continuation) {

            }

            @Override
            public void onFailure(Exception exception) {
                choose(action);
            }
        });
    }

    //determines whether to save or pull audio from account
    private void choose (int action) {
        switch (action) {
            case 1:
                upload();
                break;
            case 2:
                download();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        //clear teh cached/saved credentials so we don't use them for guest user if not logged in
        credentialsProvider.clear();
    }

    //results in upload when upload button is clicked
    public void upload (View v) {
        act (1);
    }

    //uploads audio file to s3
    public void upload() {
        String path = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).getAbsolutePath();

        File file = new File (path, "advert.png");

        AmazonS3Client s3Client = new AmazonS3Client(credentialsProvider);
        TransferUtility transferUtility = TransferUtility.builder()
                .context(getApplicationContext())
                .awsConfiguration(AWSMobileClient.getInstance().getConfiguration())
                .s3Client(s3Client).build();

        TransferObserver uploadObserver = transferUtility.upload("advert.png", file);

        uploadObserver.setTransferListener(new TransferListener() {
            @Override
            public void onStateChanged(int id, TransferState state) {
                if (TransferState.COMPLETED == state) {
                    Log.i("Completion", "Upload completed");
                }
            }

            @Override
            public void onProgressChanged(int id, long bytesCurrent, long bytesTotal) {

            }

            @Override
            public void onError(int id, Exception ex) {

            }
        });
    }

    //results in download when download button is clicked
    public void download (View v) {
        act (2);
    }

    //downloads audio file from s3
    public void download() {
        AmazonS3Client s3Client = new AmazonS3Client(credentialsProvider);

        try {
            File outputDir = getCacheDir();
            final File tempCacheFile = File.createTempFile("audio", "extension", outputDir);

            TransferUtility transferUtility = TransferUtility.builder().context(getApplicationContext())
                    .awsConfiguration(AWSMobileClient.getInstance().getConfiguration())
                    .s3Client(s3Client)
                    .build();

            TransferObserver downloadObserver = transferUtility.download("filname", tempCacheFile);

            //Attach a listener to the observer to get state update and progress notifications
            downloadObserver.setTransferListener(new TransferListener() {

                @Override
                public void onStateChanged(int id, TransferState state) {
                    if (TransferState.COMPLETED == state) {
                        //Handle a completed upload
                        Bitmap bmp = BitmapFactory.decodeFile(tempCacheFile.getAbsolutePath());

                    }
                }

                @Override
                public void onProgressChanged(int id, long bytesCurrent, long bytesTotal) {
                    float percentDonef = ((float) bytesCurrent / (float) bytesTotal * 100);
                    int percentDone = (int) percentDonef;
                }

                @Override
                public void onError(int id, Exception ex) {

                }
            });
        }
        catch (IOException io){
            Log.i("File error", "File error");
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode){
            case REQUEST_RECORD_AUDIO_PERMISSION:
                permissionToRecordAccepted  = grantResults[0] == PackageManager.PERMISSION_GRANTED;
                break;
        }
        if (!permissionToRecordAccepted ) finish();

    }

    //depending on input, starts or stops recording
    private void onRecord(boolean start) {
        if (start) {
            startRecording();
        } else {
            stopRecording();
        }
    }

    private void startRecording() {
        //sets up recorder to record
        recorder = new MediaRecorder();
        recorder.setAudioSource(MediaRecorder.AudioSource.MIC);
        recorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
        recorder.setOutputFile(fileName);
        recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);

        try {
            recorder.prepare();
        } catch (IOException e) {
            Log.e(LOG_TAG, "prepare() failed");
        }

        recorder.start();
    }

    private void stopRecording() {
        //stops and clears recorder
        recorder.stop();
        recorder.release();
        recorder = null;
    }

    public void record(View v) {
        onRecord(startRecording);
        Button record = findViewById(R.id.button_record);
        if (startRecording) {
            record.setText("Stop recording");
        } else {
            record.setText("Start recording");
        }
        startRecording = !startRecording;
    }

    private void onPlay(boolean start) {
        if (start) {
            startPlaying();
        } else {
            stopPlaying();
        }
    }

    private void startPlaying() {
        player = new MediaPlayer();
        try {
            player.setDataSource(fileName);
            player.prepare();
            player.start();
        } catch (IOException e) {
            Log.e(LOG_TAG, "prepare() failed");
        }
    }

    private void stopPlaying() {
        player.release();
        player = null;
    }

    public void play(View v) {
        onPlay(startPlaying);
        //enables access to button on screen
        Button play = findViewById(R.id.button_play);
        if (startPlaying) {
            play.setText("Stop playing");
        }
        else {
            play.setText("Start playing");
        }
        startPlaying = !startPlaying;
    }


    @Override
    public void onStop() {
        super.onStop();
        if (recorder != null) {
            recorder.release();
            recorder = null;
        }

        if (player != null) {
            player.release();
            player = null;
        }
    }
}
