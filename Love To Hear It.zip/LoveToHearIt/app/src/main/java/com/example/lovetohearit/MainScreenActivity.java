package com.example.lovetohearit;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainScreenActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_screen);
    }

    //guides user to recording activity screen upon clicking the record audio button
    public void record(View view) {
        Intent recordIntent = new Intent(this, RecordingActivity.class);
        startActivity(recordIntent);
    }

    //guides user to playing activity screen upon clicking the play audio button
    public void play(View view) {
        Intent playIntent = new Intent(this, PlayingActivity.class);
        startActivity(playIntent);
    }
}
