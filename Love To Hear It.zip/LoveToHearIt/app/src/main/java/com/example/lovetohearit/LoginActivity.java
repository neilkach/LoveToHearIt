package com.example.lovetohearit;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.amazonaws.mobile.client.AWSMobileClient;
import com.amazonaws.mobile.client.AWSStartupHandler;
import com.amazonaws.mobile.client.AWSStartupResult;

public class LoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Add a call to initialize AWSMobileClient
        AWSMobileClient.getInstance().initialize(this, new AWSStartupHandler() {
            @Override
            public void onComplete(AWSStartupResult awsStartupResult) {
                SignInUI signin = (SignInUI) AWSMobileClient.getInstance().getClient(
                        LoginActivity.this,
                        SignInUI.class);
                signin.login(
                        LoginActivity.this,
                        MainScreenActivity.class).execute();
            }
        }).execute();
    }

    //guides user to main screen activity screen upon clicking the login button if the credentials are calid
    public void mainScreen(View view) {
        Intent mainIntent = new Intent(this, MainScreenActivity.class);
        startActivity(mainIntent);
    }

    //guides user to sign up activity screen upon clicking the sign up button
    public void signup(View view) {
        Intent signupIntent = new Intent(this, SignUpActivity.class);
        startActivity(signupIntent);
    }

}
